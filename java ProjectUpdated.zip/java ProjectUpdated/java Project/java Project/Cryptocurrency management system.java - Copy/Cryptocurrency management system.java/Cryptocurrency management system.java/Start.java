import java.lang.*;
import views.*;

public class Start 
 {
   public static void main(String[] args)
    {
        WelcomeFrame we=new WelcomeFrame();
        we.setVisible(true);
    }
    
  }